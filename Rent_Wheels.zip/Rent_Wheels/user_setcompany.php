<?php
session_start();
?>
<?php
$company=$_GET['company'] ;
echo "<option>".$company."</option>";
?>