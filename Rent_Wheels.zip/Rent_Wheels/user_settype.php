<?php
session_start();
?>
<?php
$type=$_GET['type'] ;
echo "<option>".$type."</option>";
?>